classdef (Abstract) NumericalSolver < handle
    % Simplifies the base class for Inheritance and Abstraction.
    
    properties (Access = public)
        % Encapsulation: Stores the main function and initial data.
        problem_func 
        initial_data 
        result_value = NaN;
    end

    methods
        function obj = NumericalSolver(func, initial)
            % Constructor
            obj.problem_func = func;
            obj.initial_data = initial;
        end
    end

    methods (Abstract)
        % Abstraction & Polymorphism: Forces subclasses to implement these.
        solve(obj)
        displayResults(obj)
    end
end