% High-level simulation script for Crop Yield Estimation
clear
clc
% 1. Data Initialization and Preprocessing (Encapsulation)
dataManager = YieldData('yield_df.csv');
dataManager = dataManager.preprocessData();

% 2. Select Crop and Get Filtered Data
targetCrop = 'Wheat';
% FIX: Use the public method to filter the data, respecting Encapsulation.
[X_crop, Y_crop] = dataManager.filterDataByCrop(targetCrop); 

% Visualizes the raw relationship between features and the target yield
figure('Name', 'Feature Relationships');
FeatureCols = X_crop.Properties.VariableNames;

% Loop through all three features and plot against the yield (Y_crop)
for i = 1:length(FeatureCols)
    subplot(1, 3, i); % 1 row, 3 columns of plots
    scatter(X_crop{:, i}, Y_crop, 15, 'filled', 'MarkerFaceAlpha', 0.5);
    
    % Clean up variable names for titles/labels
    readableName = strrep(FeatureCols{i}, '_', ' ');
    title(['Yield vs. ', readableName]);
    xlabel(readableName);
    ylabel('Yield (hg/ha)');
    grid on;
end
sgtitle(['Raw Feature Relationships for ', targetCrop], 'FontSize', 14); 

% 3. Model Creation and Training (Polymorphism and Inheritance)
model = LinearRegressionCropModel(targetCrop); % Instantiate a concrete model
model = model.trainModel(X_crop, Y_crop);       % Train the model


% 4. Simulation and Prediction
% Use the last 5 data points for testing/prediction
numTestSamples = 5;
X_test = X_crop(end-numTestSamples+1:end, :);
Y_actual = Y_crop(end-numTestSamples+1:end);

% Predict the yield (Polymorphism ensures the correct method is called)
Y_predicted = model.predictYield(X_test);

% 5. Results and Summary
disp(' ');
disp('  YIELD ESTIMATION SIMULATION RESULTS  ');

model.displaySummary(); % Display model details

disp(' ');
disp(' Prediction vs. Actual for Last 5 Samples ');
Results = table(Y_actual, Y_predicted, 'VariableNames', {'ActualYield', 'PredictedYield'});
disp(Results);

% 1. Original Time Series Plot
figure('Name', 'Time Series Prediction');
plot(1:numTestSamples, Y_actual, 'bo-', 'LineWidth', 2);
hold on;
plot(1:numTestSamples, Y_predicted, 'rx--', 'LineWidth', 2);
title(['Yield Prediction (Time Series) for ', targetCrop]);
xlabel('Sample Index');
ylabel('Yield (hg/ha)');
legend('Actual Yield', 'Predicted Yield');
grid on;
saveas(gcf,'Time series.png');

% 2. Actual vs. Predicted Scatter Plot (New)
figure('Name', 'Actual vs. Predicted Yield');
scatter(Y_actual, Y_predicted, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;

% Plot the y=x line (the line of ideal fit)
max_val = max([Y_actual; Y_predicted]);
min_val = min([Y_actual; Y_predicted]);
plot([min_val, max_val], [min_val, max_val], 'r--', 'LineWidth', 2);

title(['Actual vs. Predicted Yield for ', targetCrop]);
xlabel('Actual Yield (hg/ha)');
ylabel('Predicted Yield (hg/ha)');
legend('Test Predictions', 'Ideal Fit', 'Location', 'best');
grid on;
saveas(gcf,'y=x line.png');

% 3. Residuals Plot (New)
Residuals = Y_actual - Y_predicted;
figure('Name', 'Residuals Plot');
scatter(Y_predicted, Residuals, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
saveas(gcf,'Residuals plot.png');

% Plot the y=0 line
plot(xlim, [0 0], 'k--');

title(['Residuals Plot for ', targetCrop]);
xlabel('Predicted Yield (hg/ha)');
ylabel('Residuals (Actual - Predicted)');
grid on;
saveas(gcf,'y=0 line.png');