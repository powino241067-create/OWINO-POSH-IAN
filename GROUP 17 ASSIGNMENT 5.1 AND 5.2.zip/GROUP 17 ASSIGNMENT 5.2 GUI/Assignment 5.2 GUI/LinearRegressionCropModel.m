classdef LinearRegressionCropModel < CropModel
    % LINEARREGRESSIONCROPMODEL: A concrete yield model using linear regression.
    
    properties
        Coefficients % Model coefficients (Encapsulation)
        Rsquared     % R-squared value
    end
    
    methods
        function obj = LinearRegressionCropModel(cropType)
            % Calls the superclass constructor (Inheritance)
            obj = obj@CropModel(cropType);
        end
        
        function obj = trainModel(obj, X, Y)
            % Polymorphism: Concrete implementation of trainModel for Linear Regression.
            disp(['Training Linear Regression Model for ', obj.CropType, '...']);
            
            % FIX: Combine the feature table (X) and response vector (Y) into a single table (T).
            % This preserves the predictor column names for the model structure.
            T = [X, table(Y, 'VariableNames', {'TargetYield'})];
            
            % Matlab's fitlm function: Use the specified formula with named variables.
            LM = fitlm(T, 'TargetYield ~ average_rain_fall_mm_per_year + pesticides_tonnes + avg_temp'); 
            
            % Store results in the inherited/own properties (Encapsulation)
            obj.ModelStructure = LM; 
            obj.Coefficients = LM.Coefficients.Estimate;
            obj.Rsquared = LM.Rsquared.Ordinary;
            
            disp('Training complete.');
        end
        
        function predictedYield = predictYield(obj, X_new)
            % Polymorphism: Concrete implementation of predictYield.
            
            if isempty(obj.ModelStructure)
                error('LinearRegressionCropModel:NotTrained', 'Model must be trained first.');
            end
            
            % X_new is already a table with the correct column names, 
            % which now match the names stored in obj.ModelStructure.
            predictedYield = predict(obj.ModelStructure, X_new);
        end
        
        function displaySummary(obj)
            % Overriding and extending the inherited displaySummary method.
            displaySummary@CropModel(obj); % Call parent method (Inheritance)
            
            disp(' Model Statistics ');
            disp(['R-squared: ', num2str(obj.Rsquared)]);
            disp('Coefficients (Intercept, Rainfall, Pesticides, Temperature):');
            disp(obj.Coefficients');
        end
    end
end