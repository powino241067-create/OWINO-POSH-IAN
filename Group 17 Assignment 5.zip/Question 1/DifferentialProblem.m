classdef DifferentialProblem < NumericalSolver
    % Inherits from NumericalSolver and implements root-finding methods.

    properties (Access = private)
        % Encapsulation: Root-finding specific parameters.
        tolerance = 1e-6;
        max_iterations = 50;
        method_used = 'None';
    end

    methods
        function obj = DifferentialProblem(func, initial_guess)
            % Calls Superclass constructor: RootFinder(@func, x0 or [x0, x1])
            obj = obj@NumericalSolver(func, initial_guess);
        end

        function solve(obj, method)
            % Polymorphism: Implements the abstract 'solve' method.
            obj.method_used = lower(method);
            x0 = obj.initial_data; % Initial guess(es)
            
            switch obj.method_used
                case 'nrm'
                    % NRM requires one initial guess
                    if length(x0) ~= 1
                        error('NRM requires one initial guess.');
                    end
                    obj.result_value = obj.newtonRaphson(x0);

                case 'secant'
                    % Secant requires two initial guesses
                    if length(x0) ~= 2
                        error('Secant requires two initial guesses: [x0, x1].');
                    end
                    obj.result_value = obj.secantMethod(x0(1), x0(2));
                    
                otherwise
                    error('Unsupported root-finding method: %s.', method);
            end
        end

        function displayResults(obj)
            % Polymorphism: Implements the abstract 'displayResults'.
            fprintf('\n Root-Finder (%s) Results:\n', upper(obj.method_used));
            fprintf('  Initial Guess(es): [%s]\n', num2str(obj.initial_data));
            if ~isnan(obj.result_value)
                fprintf('  Calculated Root (r): **%.6f**\n', obj.result_value);
                fprintf('  Function Value at Root: **%e**\n', obj.problem_func(obj.result_value));
            else
                fprintf('  Failure: Solver did not converge in %d steps.\n', obj.max_iterations);
            end
            fprintf('-------------------------------------------------\n');
        end
    end

    methods (Access = private)
        % Encapsulated methods for the algorithms
        
        function df = derivative(~, func)
            % Numerical approximation of the derivative f'(x)
            h = 1e-9;
            df = @(x) (func(x + h) - func(x)) / h;
        end

        function root = newtonRaphson(obj, x0)
            x = x0;
            df = obj.derivative(obj.problem_func);
            for i = 1:obj.max_iterations
                x_new = x - obj.problem_func(x) / df(x);
                if abs(x_new - x) < obj.tolerance
                    root = x_new; return;
                end
                x = x_new;
            end
            root = NaN;
        end

        function root = secantMethod(obj, x0, x1)
            x_prev = x0;
            x_curr = x1;
            for i = 1:obj.max_iterations
                fx_prev = obj.problem_func(x_prev);
                fx_curr = obj.problem_func(x_curr);

                if abs(fx_curr - fx_prev) < eps
                    root = NaN; return;
                end

                x_next = x_curr - fx_curr * (x_curr - x_prev) / (fx_curr - fx_prev);
                
                if abs(x_next - x_curr) < obj.tolerance
                    root = x_next; return;
                end
                x_prev = x_curr;
                x_curr = x_next;
            end
            root = NaN;
        end
    end
end